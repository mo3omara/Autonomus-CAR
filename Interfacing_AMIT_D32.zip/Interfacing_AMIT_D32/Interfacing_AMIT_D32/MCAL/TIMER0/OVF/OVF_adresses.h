
/*
 * OVF_adresses.h
 *
 * Created: 10/20/2022 3:55:02 PM
 *  Author: Omar Wessam
 */ 


/*#define OCR0  (*(volatile uint8_t*)(0X5C))
#define TIMSK (*(volatile uint8_t*)(0X59))
#define TIFR  (*(volatile uint8_t*)(0X58))
#define TCCR0 (*(volatile uint8_t*)(0X53))
#define TCNT0 (*(volatile uint8_t*)(0X52))*/
