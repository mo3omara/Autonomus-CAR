
/*
 * ADC_adresses.h
 *
 * Created: 10/14/2022 3:06:14 PM
 *  Author: Omar Wessam
 */ 
#define ADC_data (*(volatile uint16_t*)0X24)

/*
#define ADCMUX (*(volatile uint8_t*)0X27)
#define ADCSRA (*(volatile uint8_t*)0X26)
#define ADCL (*(volatile uint8_t*)0X25)
#define ADCH (*(volatile uint8_t*)0X24)*/