
/*
 * Interrupt_adresses.h
 *
 * Created: 10/13/2022 2:59:56 PM
 *  Author: Omar Wessam
 */ 
/*
#define SREG (*(volatile uint8_t*)0X5F)

#define GICR (*(volatile uint8_t*)0X5B)

#define GIFR (*(volatile uint8_t*)0X5A)

#define MCUCR (*(volatile uint8_t*)0X55)

#define MCUCSR (*(volatile uint8_t*)0X54)*/

