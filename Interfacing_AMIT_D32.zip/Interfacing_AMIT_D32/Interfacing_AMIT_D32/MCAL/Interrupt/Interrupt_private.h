
/*
 * Interrupt_private.h
 *
 * Created: 10/13/2022 3:00:41 PM
 *  Author: Omar Wessam
 */ 
#include "Interrupt_configuration.h"

void ExternalInterrupt_intialize(interrupts inter,interrupt_sense intsense);