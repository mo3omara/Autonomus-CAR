/*
 * button0_private.h
 *
 * Created: 9/30/2022 3:45:24 PM
 *  Author: Omar Wessam
 */ 


#ifndef BUTTON0_PRIVATE_H_
#define BUTTON0_PRIVATE_H_

#include "button0_configuration.h"

void BTN0_intialize (void);
Uint8_t BTN0_Read(void);



#endif /* BUTTON0_PRIVATE_H_ */