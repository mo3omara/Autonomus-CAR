/*
 * button0_private.h
 *
 * Created: 9/30/2022 3:45:24 PM
 *  Author: Omar Wessam
 */ 


#ifndef BUTTON1_PRIVATE_H_
#define BUTTON1_PRIVATE_H_

#include "button1_configuration.h"

void BTN1_intialize (void);
Uint8_t BTN1_Read(void);


#endif /* BUTTON0_PRIVATE_H_ */