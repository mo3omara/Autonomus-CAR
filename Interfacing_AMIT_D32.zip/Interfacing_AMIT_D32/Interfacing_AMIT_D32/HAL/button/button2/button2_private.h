/*
 * button2_private.h
 *
 * Created: 10/8/2022 2:00:27 PM
 *  Author: Omar Wessam
 */ 


#ifndef BUTTON2_PRIVATE_H_
#define BUTTON2_PRIVATE_H_


#include "button2_configuration.h"
void BTN2_intialize (void);
Uint8_t BTN2_Read(void);



#endif /* BUTTON2_PRIVATE_H_ */