/*
 * Ultrasonic_privat.h
 *
 * Created: 12/11/2022 5:34:20 PM
 *  Author: Omar Wessam
 */ 
#include "Ultrasonic_configuration.h"

void Ultrasonic_intialize(void);
void Ultrasonic_trigger(void);
double Ultrasonic_distance(void);
