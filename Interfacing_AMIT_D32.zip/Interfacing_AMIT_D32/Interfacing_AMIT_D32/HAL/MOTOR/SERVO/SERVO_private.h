/*
 * SERVO_private.h
 *
 * Created: 10/27/2022 11:15:14 PM
 *  Author: Omar Wessam
 */ 


#ifndef SERVO_PRIVATE_H_
#define SERVO_PRIVATE_H_
#include "SERVO_configuration.h"

void Servo_intialize(void);
void Servo_Rotate(float angle);




#endif /* SERVO_PRIVATE_H_ */