
/*
 * KEYPAD_private.h
 *
 * Created: 10/11/2022 4:22:11 PM
 *  Author: Omar Wessam
 */ 
#include "KEYPAD_configuration.h"

void KEYPAD_Intialize (void);
uint8_t  KEYPAD_Read (void);